// Matrix background effect
const canvas = document.getElementById('matrix');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const hackerAlphabet = '01';
const fontSize = 16;
const columns = canvas.width / fontSize;
const drops = Array(columns).fill(1);

function drawMatrix() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#00ff00';
    ctx.font = `${fontSize}px monospace`;

    drops.forEach((y, i) => {
        const text = hackerAlphabet[Math.floor(Math.random() * hackerAlphabet.length)];
        const x = i * fontSize;
        ctx.fillText(text, x, y * fontSize);

        if (y * fontSize > canvas.height && Math.random() > 0.975) {
            drops[i] = 0;
        }
        drops[i]++;
    });
}

setInterval(drawMatrix, 50);

// Form validation with glitch effect
function validateForm() {
    const password = document.querySelector('input[name="password"]').value;
    const confirmPassword = document.querySelector('input[name="confirmPassword"]').value;

    if (password !== confirmPassword) {
        document.querySelector('.container').classList.add('glitch');
        setTimeout(() => document.querySelector('.container').classList.remove('glitch'), 500);
        alert('Passwords do not match!');
        return false;
    }
    return true;
}
